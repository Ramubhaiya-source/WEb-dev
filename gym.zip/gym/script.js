// JavaScript to toggle the navigation menu on mobile
document.addEventListener("DOMContentLoaded", function () {
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector("nav ul");

    // When the hamburger menu is clicked, toggle the 'nav-active' class
    hamburger.addEventListener("click", () => {
        navMenu.classList.toggle("nav-active");
    });
});
